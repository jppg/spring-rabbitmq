package com.example.rabbitmqconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
